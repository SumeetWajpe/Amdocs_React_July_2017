// Code Here
import React from 'react'; // node_modules
import ReactDOM from 'react-dom';

import ShoppingCartComponent from './shoppingcart.component';

import ButtonComponent from './CustomButton';


import ButtonList from './ButtonList';

import PostsComponent from './posts.component';

// ReactDOM.render(<ButtonList listofbuttons={[20,40,60,80]} />,
//     document.getElementById('content'));


// ReactDOM.render(<ShoppingCartComponent />,
//     document.getElementById('content'));

ReactDOM.render(<PostsComponent />,
    document.getElementById('content'));



    