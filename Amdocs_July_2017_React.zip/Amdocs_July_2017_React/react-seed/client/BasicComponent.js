import React from 'react'; // node_modules

export default class BasicComponent extends React.Component{
    render(){
        return <h1> React using Dev Environment !</h1>
    }
}

export const PI = 3.14;

