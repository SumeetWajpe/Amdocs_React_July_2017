import React from 'react'; // node_modules

export default class ButtonComponent extends React.Component{
    
    constructor(props){
        super(props);
        this.state = {count: +this.props.initialcount}; // instead of parseInt
    }
    
    IncreementCount(){
        this.setState({count:this.state.count + 1});
    }
    
    render(){
        return <div>
                <input type="button"
                className="btn btn-primary"
                 value={this.state.count}
                 onClick={this.IncreementCount.bind(this)}
                  />
                    </div>
    }
}



