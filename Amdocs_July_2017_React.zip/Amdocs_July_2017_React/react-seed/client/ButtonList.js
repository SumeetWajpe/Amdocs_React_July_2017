import React from 'react';
import ReactDOM from 'react-dom';


import ButtonComponent from './CustomButton';

export default class ButtonList extends React.Component{
    constructor(props){
        super(props);
        this.state = {list:this.props.listofbuttons};
    }


    ClickHandler(){      
        // 1. get the value from text box
        // 2. create a new state = old state + new added value
        //3. set the new state
            var txtValue = ReactDOM.findDOMNode(this.refs.inputValue).value;

            var newState = [...this.state.list,txtValue];// ES 6 spread operator

        this.setState({list:newState});
    }

    render(){
        //button collection
        var buttonsTobCreated = this.state.list.map(function(val,ind){
            return <ButtonComponent initialcount={val} key={ind * Math.random()} />
        });

        return <div>
                  
                    <input type="text" className="form-control" ref="inputValue" />

                    <input type="button" value="ADD" className="btn btn-success" onClick={this.ClickHandler.bind(this)} />
                       
                   
             
                        {buttonsTobCreated}
                    </div>

    }
}