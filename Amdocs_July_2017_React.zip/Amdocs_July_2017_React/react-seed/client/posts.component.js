import React from 'react';


export default class PostsComponent extends React.Component{

    constructor(props){
        super(props);
        this.state = {posts:[]};
    }

    componentDidMount(){
        var self = this;
        $.get('https://jsonplaceholder.typicode.com/posts',function(response){
            //console.log(response);
            self.setState({posts:response});

        }); // eof get
    }// eof componentDidMount

    render(){
        var postsToBcreated = this.state.posts.map(function(p,i){
            return <li key={i}> {p.title} </li>
        });

        return <div>
                <ul>
                    {postsToBcreated}
                </ul>
        </div>
    }
}