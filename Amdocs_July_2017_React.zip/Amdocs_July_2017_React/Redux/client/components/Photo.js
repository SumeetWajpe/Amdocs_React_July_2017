import React from 'react';
import {Link} from 'react-router';


export default class Photo extends React.Component{
    render(){
        return  <div className="PhotoDetails">
            <b>{this.props.post.caption}</b><br/>
            <Link to={`/photo/${this.props.post.code}`}>
            <img height="100px" 
            width="100px"
            src={this.props.post.display_src}
             />
             </Link>
              <br/>
             <button className="btn btn-primary"
             onClick={this.props.IncrementLikes.bind(null,this.props.i)}
             >{this.props.post.likes}
                 &nbsp;&nbsp;<span className="glyphicon glyphicon-thumbs-up"></span>
             </button>
            </div>
    }
}