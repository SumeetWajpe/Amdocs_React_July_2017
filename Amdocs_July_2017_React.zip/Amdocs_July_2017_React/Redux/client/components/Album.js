import React from 'react';
import Photo from './Photo';

export default class Album extends React.Component{
    render(){
        return  <div>
            <h3> Albums  ! </h3>

        {
            this.props.myposts.map((item,index)=>{
                return <Photo post={item} key={index} {...this.props} 
                i={index} />
            })
        }


            </div>
    }
}