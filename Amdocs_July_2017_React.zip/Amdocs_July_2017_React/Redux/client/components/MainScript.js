import {connect} from 'react-redux';

import {bindActionCreators}  from 'redux';

import * as actions from '../actions/actionCreators';

import Main from './Main';

function mapStateToProps(storeData){
            return{
                myposts:storeData.posts,
                mycomments:storeData.comments
            }
}

function mapDispatchToProps(dispatch){
        return bindActionCreators(actions,dispatch);
}

var App = connect(mapStateToProps,mapDispatchToProps)(Main);

export default App;