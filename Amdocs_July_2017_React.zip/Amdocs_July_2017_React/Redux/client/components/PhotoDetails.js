import React from 'react';
import Photo from './Photo';

export default class PhotoDetails extends React.Component{
    render(){
        let code = this.props.params.code;
        let index = this.props.myposts.findIndex((post) => post.code == code);

        let thePost = this.props.myposts[index];        

        return  <div>

            <h1> Photo Details :  </h1>
             <Photo post={thePost} i={index} {...this.props} /> 
            </div>
    }
}