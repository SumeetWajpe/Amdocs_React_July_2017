export default function posts(defState=[],action){
    switch(action.type){
        case 'INCREMENT_LIKES':
        // change the store and return new store;
        var index = action.index;

        return [

            ...defState.slice(0,index),// copy previous objects as they are
            {...defState[index],likes:defState[index].likes + 1},
            ...defState.slice(index + 1)//copy next objects as they are

        ];

        break;
               
       default:
                return defState;

    }
}