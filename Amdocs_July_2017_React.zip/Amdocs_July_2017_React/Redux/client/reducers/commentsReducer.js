export default function comments(defState=[],action){
    switch(action.type){
        case 'ADD_POSTS':
        // change the store and return new store;
        console.log('Within commentsReducer ! ' );
                console.log(action.type);

       // break;
                return defState;
        default:
                return defState;

    }
}