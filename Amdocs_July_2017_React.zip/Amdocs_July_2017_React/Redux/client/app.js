// Code Here

import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux';

import store from './store';
import App from './components/MainScript';

import Album from './components/Album';
import Main from './components/Main';
import Photo from './components/Photo';
import PhotoDetails from './components/PhotoDetails';



import {Router,Route,IndexRoute,browserHistory} from 'react-router';

var router = <Provider store={store}>
                    <Router history={browserHistory}>
                    <Route path="/" component={App}>
                        <IndexRoute component={Album}></IndexRoute>
                        <Route path="/photo/:code" component={PhotoDetails}></Route>
                    </Route>
                    </Router>
                    </Provider>
ReactDOM.render(router,document.getElementById('content'));