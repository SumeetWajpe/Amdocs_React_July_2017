import {createStore} from 'redux';
import rootReducer from './reducers/rootReducer';
// data
import posts from './data/posts';
import comments from './data/comments';

// var defaultData = {posts:posts,comments:comments};

//ES 6

var defaultData = {posts,comments}; // enhanced object literal syntax

var store = createStore(rootReducer,defaultData);

export default store;
