export function IncrementLikes(index){
        return{
            type:'INCREMENT_LIKES',
            index:index
        }
}

export function DecrementLikes(index){
    return{
            type:'DECREMENT_LIKES',
            index:index
        }
}

export function AddPosts(){
    return {type:'ADD_POST'};
}