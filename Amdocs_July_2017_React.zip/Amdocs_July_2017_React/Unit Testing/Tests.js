function   Add(x,y){
    return  x + y;
}

describe("A suite", function() {
  it("contains spec with an expectation", function() {
    expect(true).toBe(true);
  });
});

describe('My Test Suite !',function   (){
    it('Adds two numbers',function(){
        expect(Add(10,20)).toBe(30);
    });
})